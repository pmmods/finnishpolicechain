fx_version 'cerulean'
game 'gta5'
author 'csnaah'

files {
  'mp_m_freemode_01_poliisi.meta',
  'first_person_alternates_poliisi.meta'
}

data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_m_freemode_01_poliisi.meta'
data_file 'PED_FIRST_PERSON_ALTERNATE_DATA' 'first_person_alternates_poliisi.meta'
